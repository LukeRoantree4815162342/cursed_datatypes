from .cursed_datatypes import (cursed_list, 
                               cursed_tuple)
